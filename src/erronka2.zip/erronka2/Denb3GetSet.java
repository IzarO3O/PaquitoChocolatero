package erronka2;

/**
 * 
 */
public class Denb3GetSet {

	public static String TaldeIzen;
	public static int Irabaziak;
	public static int Galerak;
	public static int Berdina;
	public static int d;
	
	public String getTaldeIzen() {
		return TaldeIzen;
	}
	public void setTaldeIzen(String taldeIzen) {
		TaldeIzen = taldeIzen;
	}
	public int getIrabaziak() {
		return Irabaziak;
	}
	public void setIrabaziak(int irabaziak) {
		Irabaziak = irabaziak;
	}
	public int getGalerak() {
		return Galerak;
	}
	public void setGalerak(int galerak) {
		Galerak = galerak;
	}
	public int getBerdina() {
		return Berdina;
	}
	public void setBerdina(int berdina) {
		Berdina = berdina;
	}
	public int getd() {
		return d;	
	}
	public void setd(int D) {
		d = D;
	}
	
}
